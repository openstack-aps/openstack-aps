//["mamasu/Widgets/Tabs", {
//    tabs: [{
//            label: "",
//            onClick: function () {
//
//            },
//            active: true
//        }
//    ]
//}],