define([], function() {
    return {
        app: "http://openstack.parallels.com/app",
        dc: "http://openstack.parallels.com/dc",
        heatstack: "http://openstack.parallels.com/heatstack",
        image: "http://openstack.parallels.com/image",
        ip: "http://openstack.parallels.com/ip",
        ipassigned: "http://openstack.parallels.com/ipassigned",
        ippool: "http://openstack.parallels.com/ippool",
        organization: "http://openstack.parallels.com/organization",
        profile: "http://openstack.parallels.com/profile",
        unmanagedve: "http://openstack.parallels.com/unmanagedve"
    };
});