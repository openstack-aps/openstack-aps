<?php

require "common.php";

/**
 * Class Image
 * @author("The Mamasu Agency")
 * @type("http://openstack.parallels.com/image/1.5")
 * @implements("http://aps-standard.org/types/core/resource/1.0")
 */
class image extends \APS\ResourceBase {

    /**
     * @link("http://openstack.parallels.com/dc")
     * @required
     */
    public $dc;

    /**
     * @link("http://openstack.parallels.com/unmanagedve[]")
     */
    public $unmanagedve;

    /**
     * @type("string")
     * @title("Id")
     */
    public $id;

    /**
     * @type("string")
     * @title("Name")
     */
    public $name;

    /**
     * @type("string")
     * @title("Image")
     */
    public $image;

    /**
     * @type("string")
     * @title("OS")
     */
    public $os;

    /**
     * @type("string")
     * @title("ISO Status")
     */
    public $isostatus;

    /**
     * @type("integer")
     * @title("Assigned Slot")
     */
    public $slot;

    /**
     * @type("integer")
     * @title("Default Image")
     * @description("To identify all custom images can be used and will not found on images list")
     */
    public $default = 0;

    /**
     * @type("string")
     * @title("Usage")
     */
    public $usage;

    /**
     * @type("string")
     * @title("Status")
     */
    public $status;

    public function provision() {
        $apsc = \APS\Request::getController();
        $dc = $apsc->getResource($this->dc->aps->id);

        $os = new OS($dc->apiurl, $dc->user, $dc->password);

        if ($this->id != "default") {
            $image = $os->getImageDetails($this->id);

            $this->image = $image->file;
            $this->isostatus = $image->status;
        }
    }

    /**
     * @verb(PUT)
     * @path("/updateimage")
     * @return(string, text/json)
     */
    public function updateImage() {
        $apsc = \APS\Request::getController();
        $dc = $apsc->getResource($this->dc->aps->id);

        $os = new OS($dc->apiurl, $dc->user, $dc->password);
        $image = $os->getImageDetails($this->id);

        $this->isostatus = $image->status;
        return json_encode($this);
    }

    public function configure($new) {
        
    }

    public function unprovision() {
        
    }

    public function upgrade() {
        
    }

}
